# Micro 2.0 Plugins

This repository contains plugins that have been updated for micro 2.0. The goal is to
have these changes merged back into the original plugin repositories, but in the meantime the updated
versions will be available here.
