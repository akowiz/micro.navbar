Provides a `fzf` command in micro to open a file in the current pane using fzf.
