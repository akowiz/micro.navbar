# Join Lines Plugin for Micro

This plugin provides the ability to join selected lines in micro.

Install with `> plugin install join-lines`.
