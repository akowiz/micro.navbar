# Join Lines Plugin

The default binding to join a selected line is `Alt-j`,
but you can easily modify that in your `bindings.json` file:

```json
{
    "Alt-k": "joinLines.joinLines"
}
```