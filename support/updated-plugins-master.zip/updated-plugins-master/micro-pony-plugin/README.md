# micro-pony-plugin
Pony plugin for the Micro text editor

Install with `> plugin install pony`.
