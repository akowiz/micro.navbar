# Pony Plugin

The Pony plugin provides auto-indentation for Pony syntax. More features will likely be added in the future.
