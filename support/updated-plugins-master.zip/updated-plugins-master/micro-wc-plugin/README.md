# Micro Word Count Plugin

*Written in Go*

Word and character counter for micro editor.
